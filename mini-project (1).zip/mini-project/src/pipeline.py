"""
Mini Project - Explainable AI on RDF data
Strategy 2a: Convert RDF (AIFB dataset) to tabular data, train a classical
ML model, and explain its predictions with SHAP + an interpretable
surrogate decision tree.

Task: Given a person (node) in the AIFB knowledge graph, predict which
research group they belong to.

Run:
    python src/pipeline.py --step all

Author: <YOUR NAMES HERE>
"""
import argparse
import os
import zipfile
import urllib.request
import json
from collections import Counter

import numpy as np
import pandas as pd
import rdflib
from rdflib import Graph, URIRef

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    classification_report,
)

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

DATA_DIR = os.path.join(os.path.dirname(__file__), "..", "data")
AIFB_URL = "https://data.dgl.ai/dataset/rdf/aifb-hetero.zip"
AIFB_ZIP = os.path.join(DATA_DIR, "aifb-hetero.zip")
AIFB_DIR = os.path.join(DATA_DIR, "aifb-hetero")

# The label predicate/URI used in the classic AIFB benchmark task
AFFILIATION_PRED = "http://swrc.ontoware.org/ontology#affiliation"
PERSON_TYPE = "http://swrc.ontoware.org/ontology#Person"


# --------------------------------------------------------------------------
# 1. Download & load
# --------------------------------------------------------------------------
def download_aifb():
    os.makedirs(DATA_DIR, exist_ok=True)
    if not os.path.exists(AIFB_ZIP):
        print(f"Downloading AIFB dataset from {AIFB_URL} ...")
        urllib.request.urlretrieve(AIFB_URL, AIFB_ZIP)
    if not os.path.exists(AIFB_DIR):
        print("Extracting ...")
        with zipfile.ZipFile(AIFB_ZIP, "r") as z:
            z.extractall(AIFB_DIR)
    print("Done. Files:", os.listdir(AIFB_DIR))


def find_n3_file():
    """Locate the .n3/.nt/.ttl graph file inside the extracted archive,
    or fall back to a manually-placed file such as data/aifbfixed_complete.n3."""
    # 1. manually placed / pre-downloaded file (e.g., aifbfixed_complete.n3)
    manual = os.path.join(DATA_DIR, "aifbfixed_complete.n3")
    if os.path.exists(manual):
        return manual

    # 2. look inside the extracted DGL archive
    if os.path.exists(AIFB_DIR):
        for root, _, files in os.walk(AIFB_DIR):
            for f in files:
                if f.endswith((".n3", ".nt", ".ttl", ".nq")):
                    return os.path.join(root, f)

    raise FileNotFoundError(
        "Could not find an RDF file. Either let --step download fetch "
        "aifb-hetero.zip, or place aifbfixed_complete.n3 directly in data/."
    )


def load_graph():
    path = find_n3_file()
    print(f"Parsing {path} with rdflib ...")
    g = Graph()
    fmt = "nt" if path.endswith(".nt") else "n3" if path.endswith(".n3") else "turtle"
    g.parse(path, format=fmt)
    print(f"Loaded graph with {len(g)} triples.")
    return g


# --------------------------------------------------------------------------
# 2. Data analysis
# --------------------------------------------------------------------------
def analyze_graph(g: Graph):
    stats = {}
    stats["num_triples"] = len(g)

    subjects = set()
    objects = set()
    predicates = Counter()
    for s, p, o in g:
        subjects.add(s)
        objects.add(o)
        predicates[str(p)] += 1

    stats["num_unique_subjects"] = len(subjects)
    stats["num_unique_objects"] = len(objects)
    stats["num_unique_entities"] = len(subjects | objects)
    stats["num_unique_predicates"] = len(predicates)
    stats["top_predicates"] = predicates.most_common(15)

    # Label distribution (affiliation -> research group)
    aff = URIRef(AFFILIATION_PRED)
    label_counts = Counter()
    for s, p, o in g.triples((None, aff, None)):
        label_counts[str(o)] += 1
    stats["label_distribution"] = label_counts.most_common()

    print(json.dumps({k: v for k, v in stats.items() if k != "top_predicates"},
                      indent=2, default=str))
    print("\nTop predicates:")
    for pred, cnt in stats["top_predicates"]:
        print(f"  {cnt:6d}  {pred}")
    print("\nLabel distribution (research group -> #persons):")
    for lbl, cnt in stats["label_distribution"]:
        print(f"  {cnt:4d}  {lbl}")

    with open(os.path.join(DATA_DIR, "stats.json"), "w") as f:
        json.dump(stats, f, indent=2, default=str)

    # simple bar chart of label distribution
    labels = [l.split("/")[-1] for l, _ in stats["label_distribution"]]
    counts = [c for _, c in stats["label_distribution"]]
    plt.figure(figsize=(6, 4))
    plt.bar(labels, counts)
    plt.xticks(rotation=45, ha="right")
    plt.ylabel("# persons")
    plt.title("AIFB: research group distribution")
    plt.tight_layout()
    out = os.path.join(DATA_DIR, "label_distribution.png")
    plt.savefig(out, dpi=150)
    print(f"Saved plot to {out}")
    return stats


# --------------------------------------------------------------------------
# 3. RDF -> tabular conversion (one-hot encoding of outgoing edges)
# --------------------------------------------------------------------------
def rdf_to_dataframe(g: Graph, max_features=500):
    """
    Build a one-hot encoded table:
      - one row per Person entity that has an affiliation (label)
      - one column per (predicate, object) pair that occurs for that person
        EXCLUDING the affiliation predicate itself (that's the label) AND
        EXCLUDING its exact inverse to prevent data leakage.

    IMPORTANT (data leakage): AIFB's `swrc:member` predicate is used both
    for ResearchGroup->Person ("this group has this member", i.e. the
    literal inverse of the `affiliation` label) and for
    Project->Person ("this project has this member"). We must exclude
    only the former, since including it would let the label leak directly
    into the features (a ResearchGroup "having a person as a member" is
    definitionally identical to that person's affiliation). This is
    standard practice in the AIFB benchmark literature, which excludes
    `affiliation`/`employs`-style relations from the feature set.
    """
    aff = URIRef(AFFILIATION_PRED)
    member_pred = URIRef("http://swrc.ontoware.org/ontology#member")
    research_group_type = URIRef("http://swrc.ontoware.org/ontology#ResearchGroup")
    research_groups = set(g.subjects(
        URIRef("http://www.w3.org/1999/02/22-rdf-syntax-ns#type"), research_group_type
    ))

    # 1. find all persons with a label
    person_labels = {}
    for s, p, o in g.triples((None, aff, None)):
        person_labels[s] = str(o)

    print(f"Found {len(person_labels)} labeled persons.")

    # 2. collect (predicate, object) feature occurrences per person
    #    only 1-hop features to keep it simple & fast
    person_features = {p: set() for p in person_labels}
    feature_counts = Counter()

    for person in person_labels:
        for s, p, o in g.triples((person, None, None)):
            if p == aff:
                continue
            feat = f"{p}::{o}"
            person_features[person].add(feat)
            feature_counts[feat] += 1
        # also consider incoming edges (e.g., publishes -> person)
        for s, p, o in g.triples((None, None, person)):
            if p == member_pred and s in research_groups:
                continue  # exact inverse of the affiliation label -> leakage
            feat = f"{p}(in)::{s}"
            person_features[person].add(feat)
            feature_counts[feat] += 1

    # 3. keep only the most frequent features to limit dimensionality
    top_features = [f for f, _ in feature_counts.most_common(max_features)]
    feature_index = {f: i for i, f in enumerate(top_features)}

    rows = []
    labels = []
    persons = list(person_labels.keys())
    X = np.zeros((len(persons), len(top_features)), dtype=np.int8)
    for i, person in enumerate(persons):
        for feat in person_features[person]:
            if feat in feature_index:
                X[i, feature_index[feat]] = 1
        labels.append(person_labels[person])

    df = pd.DataFrame(X, columns=top_features)
    df["person"] = [str(p) for p in persons]
    df["label"] = labels
    return df


# --------------------------------------------------------------------------
# 4. Model training & evaluation
# --------------------------------------------------------------------------
def train_and_evaluate(df: pd.DataFrame, seed=42):
    # Drop classes with fewer than 2 members: they cannot be stratified into
    # train/test splits. This matches standard practice for AIFB (e.g., the
    # RDF2Vec paper removes the smallest research group of 4/1 members,
    # leaving 4 usable classes).
    label_counts = df["label"].value_counts()
    valid_labels = label_counts[label_counts >= 2].index
    dropped = label_counts[label_counts < 2]
    if len(dropped) > 0:
        print(f"Dropping {len(dropped)} class(es) with <2 members: "
              f"{dict(dropped)}")
    df = df[df["label"].isin(valid_labels)].reset_index(drop=True)

    feature_cols = [c for c in df.columns if c not in ("person", "label")]
    X = df[feature_cols].values
    y = df["label"].values

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=seed, stratify=y
    )

    clf = RandomForestClassifier(
        n_estimators=200, max_depth=8, random_state=seed, class_weight="balanced"
    )
    clf.fit(X_train, y_train)

    results = {}
    for split_name, Xs, ys in [("train", X_train, y_train), ("test", X_test, y_test)]:
        pred = clf.predict(Xs)
        results[split_name] = {
            "accuracy": accuracy_score(ys, pred),
            "precision_macro": precision_score(ys, pred, average="macro", zero_division=0),
            "recall_macro": recall_score(ys, pred, average="macro", zero_division=0),
            "f1_macro": f1_score(ys, pred, average="macro", zero_division=0),
        }
        print(f"\n== {split_name} ==")
        print(classification_report(ys, pred, zero_division=0))

    with open(os.path.join(DATA_DIR, "model_performance.json"), "w") as f:
        json.dump(results, f, indent=2)

    return clf, feature_cols, X_train, X_test, y_train, y_test


# --------------------------------------------------------------------------
# 5. Explanations: SHAP (local) + surrogate decision tree (global)
# --------------------------------------------------------------------------
def explain_with_shap(clf, feature_cols, X_train, X_test, df_test_persons, out_dir):
    import shap
    explainer = shap.TreeExplainer(clf)
    raw_shap_values = explainer.shap_values(X_test)

    # Normalize SHAP output across shap versions into a list of
    # (n_samples, n_features) arrays, one per class.
    if isinstance(raw_shap_values, list):
        shap_values = raw_shap_values
    elif raw_shap_values.ndim == 3:
        # shape (n_samples, n_features, n_classes) -> list of per-class arrays
        shap_values = [raw_shap_values[:, :, c] for c in range(raw_shap_values.shape[2])]
    else:
        # binary / regression case: single (n_samples, n_features) array
        shap_values = [raw_shap_values]

    # global summary plot (use class 0 as representative view)
    plt.figure()
    shap.summary_plot(shap_values[0], X_test, feature_names=feature_cols, show=False)
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "shap_summary.png"), dpi=150)
    plt.close()

    # one local explanation example (first test instance)
    idx = 0
    pred_class_idx = int(np.argmax(clf.predict_proba(X_test[idx:idx+1])[0]))
    pred_class_idx = min(pred_class_idx, len(shap_values) - 1)
    contribs = shap_values[pred_class_idx][idx]
    top_idx = np.argsort(-np.abs(contribs))[:10]

    explanation = {
        "person": df_test_persons.iloc[idx],
        "predicted_class": clf.classes_[pred_class_idx],
        "top_features": [
            {"feature": human_readable_feature(feature_cols[i]),
             "shap_value": float(contribs[i])}
            for i in top_idx
        ],
    }
    with open(os.path.join(out_dir, "example_explanation.json"), "w") as f:
        json.dump(explanation, f, indent=2)
    print("\nExample local explanation:")
    print(json.dumps(explanation, indent=2))
    return explanation


def human_readable_feature(feat: str) -> str:
    """Turn 'http://.../worksAtProject::http://.../id123' into something readable."""
    if "::" in feat:
        pred, obj = feat.split("::", 1)
        pred_short = pred.split("/")[-1].split("#")[-1].replace("(in)", " (incoming)")
        obj_short = obj.split("/")[-1]
        return f"{pred_short} -> {obj_short}"
    return feat


def surrogate_decision_tree(clf, feature_cols, X_train, y_train, out_dir, max_depth=4):
    """Train an interpretable decision tree to approximate the RF (global surrogate)."""
    rf_preds_train = clf.predict(X_train)  # fit surrogate on RF's own predictions
    surrogate = DecisionTreeClassifier(max_depth=max_depth, random_state=42)
    surrogate.fit(X_train, rf_preds_train)

    fidelity = surrogate.score(X_train, rf_preds_train)
    print(f"\nSurrogate decision tree fidelity to RF (train set): {fidelity:.3f}")

    readable_features = [human_readable_feature(f) for f in feature_cols]
    tree_text = export_text(surrogate, feature_names=readable_features)
    with open(os.path.join(out_dir, "surrogate_tree.txt"), "w") as f:
        f.write(f"Fidelity to RF (train set): {fidelity:.3f}\n\n")
        f.write(tree_text)
    print(tree_text[:2000])
    return surrogate, fidelity


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--step", choices=["download", "analyze", "train", "explain", "all"],
                         default="all")
    args = parser.parse_args()

    if args.step in ("download", "all"):
        download_aifb()

    g = load_graph()

    if args.step in ("analyze", "all"):
        analyze_graph(g)

    df = rdf_to_dataframe(g)
    df.to_csv(os.path.join(DATA_DIR, "aifb_tabular.csv"), index=False)
    print(f"Tabular dataset shape: {df.shape}")

    if args.step in ("train", "explain", "all"):
        clf, feature_cols, X_train, X_test, y_train, y_test = train_and_evaluate(df)

    if args.step in ("explain", "all"):
        # need test-set persons for the explanation example; apply the same
        # rare-class filter as train_and_evaluate so splits are consistent
        label_counts = df["label"].value_counts()
        valid_labels = label_counts[label_counts >= 2].index
        df_filtered = df[df["label"].isin(valid_labels)].reset_index(drop=True)
        _, df_test = train_test_split(df_filtered, test_size=0.3, random_state=42,
                                       stratify=df_filtered["label"])
        explain_with_shap(clf, feature_cols, X_train, X_test,
                           df_test["person"].reset_index(drop=True), DATA_DIR)
        surrogate_decision_tree(clf, feature_cols, X_train, y_train, DATA_DIR)

    print("\nAll artifacts written to:", os.path.abspath(DATA_DIR))


if __name__ == "__main__":
    main()
